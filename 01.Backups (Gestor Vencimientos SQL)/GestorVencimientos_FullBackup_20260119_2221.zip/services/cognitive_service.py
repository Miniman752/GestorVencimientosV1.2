from statistics import mean, stdev
from typing import Optional
from sqlalchemy import func
from utils.decorators import safe_transaction
from models.entities import Vencimiento, EstadoVencimiento

class CognitiveService:
    """
    Advanced cognitive analysis for anomaly detection and pattern recognition.
    Acts as a proactive brain monitoring data entry.
    """
    
    @staticmethod
    def predict_category(text: str) -> Optional[str]:
        """
        Predicts category based on provider name using keyword clustering.
        Returns the value of CategoriaServicio or None.
        """
        if not text: return None
        text = text.lower().strip()
        
        # Mapping (Clustering)
        keywords = {
            "Impuesto": ["arba", "agip", "afip", "patente", "inmobiliario", "municipal", "rentas", "impuesto", "monotributo"],
            "Expensa": ["expensa", "consorcio", "administracion", "edificio", "torre"],
            "Servicio": ["luz", "gas", "agua", "internet", "fibertel", "telecentro", "personal", "movistar", "claro", "edesur", "edenor", "metrogas", "naturgy", "aysa", "seguro", "netflix", "spotify", "visa", "master", "amex", "tarjeta", "cable"]
        }
        
        for cat, terms in keywords.items():
            for term in terms:
                if term in text:
                    return cat # Matches CategoriaServicio values strings
        
        return None
    @staticmethod
    @safe_transaction
    def detect_anomaly(obligacion_id: int, new_amount: float, session=None) -> tuple[bool, str]:
        """
        Analyzes historical payments for this obligation to detect anomalies.
        Returns: (True/False, Reason Argument)
        """
        if not obligacion_id:
            return False, ""
            
        # 1. Fetch History (Last 6 payments)
        history = session.query(Vencimiento).filter(
            Vencimiento.obligacion_id == obligacion_id,
            Vencimiento.estado == EstadoVencimiento.PAGADO,
            Vencimiento.is_deleted == 0
        ).order_by(Vencimiento.fecha_vencimiento.desc()).limit(6).all()
        
        if len(history) < 3:
            return False, "Insuficiente data histórica"

         # Convert to float for stat calc
        amounts = [float(h.monto_original) for h in history]
        
        # 2. Heuristics
        avg = mean(amounts)
        
        # Threshold: 40% deviation from Moving Average
        threshold = 0.4
        
        # Check High Anomaly
        if new_amount > avg * (1 + threshold):
            pct_diff = int(((new_amount - avg) / avg) * 100)
            return True, f"El monto ingresado (${new_amount:,.2f}) es un {pct_diff}% mayor al promedio histórico (${avg:,.2f}).\n¿Confirma que es correcto?"
            
        # Check Low Anomaly (Suspiciously low)
        if new_amount < avg * (1 - threshold):
             pct_diff = int(((avg - new_amount) / avg) * 100)
             return True, f"El monto ingresado es un {pct_diff}% menor al promedio histórico.\nPosible error de tipeo o factura parcial."

        return False, ""

    @staticmethod
    @safe_transaction
    def check_duplicate(obligacion_id: int, periodo: str, session=None) -> bool:
        """
        Checks if a record already exists for this Obligation + Period.
        Returns True if duplicate found.
        """
        count = session.query(func.count(Vencimiento.id)).filter(
            Vencimiento.obligacion_id == obligacion_id,
            Vencimiento.periodo == periodo,
            Vencimiento.is_deleted == 0
        ).scalar()
        
        return count > 0


        return count > 0

    @staticmethod
    @safe_transaction
    def get_insights(session=None) -> list:
        """
        Generates proactive financial insights.
        Returns: List of dicts {'type': 'warning/info/good', 'text': '...'}
        """
        insights = []
        from datetime import date, timedelta
        import calendar
        
        today = date.today()
        # 1. Urgent Deadlines (Next 48h)
        # Using today + 2 days
        limit_date = today + timedelta(days=2)
        
        urgent_count = session.query(func.count(Vencimiento.id)).filter(
            Vencimiento.estado == EstadoVencimiento.PENDIENTE,
            Vencimiento.fecha_vencimiento >= today,
            Vencimiento.fecha_vencimiento <= limit_date,
            Vencimiento.is_deleted == 0
        ).scalar() or 0
        
        if urgent_count > 0:
            insights.append({
                "type": "info",
                "text": f"📅 Tienes {urgent_count} vencimientos en las próximas 48hs."
            })
            
        # 2. Inflation Alert (MoM Spending)
        # Compare current month vs prev month total (Original Amounts)
        # Current month
        curr_month_str = today.strftime("%m-%Y")
        
        # Prev month logic
        year = today.year
        month = today.month
        prev_month = month - 1
        prev_year = year
        if prev_month == 0:
            prev_month = 12
            prev_year = year - 1
        prev_month_str = f"{prev_month:02d}-{prev_year}"
        
        # Calc totals (All obligations, regardless of payment status, to see 'spending pressure')
        curr_total = session.query(func.sum(Vencimiento.monto_original)).filter(
            Vencimiento.periodo == curr_month_str,
            Vencimiento.is_deleted == 0
        ).scalar()
        curr_total = float(curr_total or 0)

        prev_total = session.query(func.sum(Vencimiento.monto_original)).filter(
            Vencimiento.periodo == prev_month_str,
            Vencimiento.is_deleted == 0
        ).scalar()
        prev_total = float(prev_total or 0)
        
        if prev_total > 0 and curr_total > prev_total:
            # Check % increase
            pct_inc = ((curr_total - prev_total) / prev_total)
            if pct_inc > 0.15: # 15% threshold
                insights.append({
                    "type": "warning",
                    "text": f"📉 Alerta Inflación: Tus gastos subieron un {int(pct_inc*100)}% vs mes anterior."
                })
        
        # 3. Good News (Completion)
        # If > 90% of current month is PAID
        if curr_total > 0:
            curr_paid_val = session.query(func.sum(Vencimiento.monto_original)).filter(
                Vencimiento.periodo == curr_month_str,
                Vencimiento.estado == EstadoVencimiento.PAGADO,
                Vencimiento.is_deleted == 0
            ).scalar()
            curr_paid = float(curr_paid_val or 0)
            
            completion = curr_paid / curr_total
            if completion >= 0.90:
                 insights.append({
                    "type": "good",
                    "text": f"🎉 ¡Excelente! Has cubierto el {int(completion*100)}% de tus obligaciones de este mes."
                })
        
        return insights


