from datetime import date
from sqlalchemy.orm import Session
from database import SessionLocal
from models.entities import PeriodoContable, EstadoPeriodo
from utils.exceptions import PeriodLockedError
from utils.logger import app_logger
from utils.decorators import safe_transaction

class PeriodService:
    @staticmethod
    def get_period_id(dt: date) -> str:
        """Returns 'YYYY-MM' from a date."""
        return dt.strftime("%Y-%m")

    @staticmethod
    def ensure_period_exists(period_id: str, session: Session) -> PeriodoContable:
        """Gets or creates a Period record. Defaults to OPEN."""
        p = session.query(PeriodoContable).filter_by(periodo_id=period_id).first()
        if not p:
            p = PeriodoContable(periodo_id=period_id, estado=EstadoPeriodo.ABIERTO.value)
            session.add(p)
            # We don't commit here to let the caller handle transactions, 
            # but usually this is called within a larger flow.
            # If standalone, caller must commit.
        return p

    @staticmethod
    @safe_transaction
    def check_period_status(target_date: date, session=None):
        """
        Checks if the period for the given date is writable.
        Raises PeriodLockedError if LOCKED.
        Returns status (for warning if CLOSED).
        """
        if not target_date: return EstadoPeriodo.ABIERTO # Safety

        pid = PeriodService.get_period_id(target_date)
        p = PeriodService.ensure_period_exists(pid, session)
        # session.commit() # Handled by decorator if needed, but ensure_period_exists doesn't flush? 
        # Actually ensure_period_exists adds it. Decorator will commit.
        
        # Handle String vs Enum comparison
        state_val = p.estado.value if hasattr(p.estado, 'value') else str(p.estado)
        
        if state_val == EstadoPeriodo.BLOQUEADO.value:
            raise PeriodLockedError(f"El período {pid} está BLOQUEADO y no admite cambios.")
        
        # Return Enum if possible for consistency, or map back?
        # Simpler: just return the string or value matching the Enum
        return next((e for e in EstadoPeriodo if e.value == state_val), state_val)



    @staticmethod
    @safe_transaction
    def create_period(year: int, month: int, session: Session = None):
        """Creates a new period if it doesn't exist."""
        period_id = f"{year}-{month:02d}"
        if session.query(PeriodoContable).filter_by(periodo_id=period_id).first():
            raise ValueError(f"El período {period_id} ya existe.")
        
        p = PeriodoContable(periodo_id=period_id, estado=EstadoPeriodo.ABIERTO.value)
        session.add(p)
        return p

    @staticmethod
    @safe_transaction
    def update_period(period_id: str, status: EstadoPeriodo, notes: str = None, user: str = None, session=None):
        p = session.query(PeriodoContable).filter_by(periodo_id=period_id).first()
        if not p: raise ValueError("Período no encontrado")
        
        p.estado = status.value if hasattr(status, 'value') else str(status)
        if notes is not None: p.notas = notes
        if notes is not None: p.notas = notes
        # if user is not None: p.usuario_responsable = user # Field missing in DB model
        
        if status != EstadoPeriodo.ABIERTO and not p.fecha_cierre:
            p.fecha_cierre = date.today()
        elif status == EstadoPeriodo.ABIERTO:
             p.fecha_cierre = None
            
        return True

    @staticmethod
    @safe_transaction
    def delete_period(period_id: str, session=None):
        from models.entities import Vencimiento
        from utils.exceptions import AppIntegrityError
        
        # 1. Integrity Check
        count = session.query(Vencimiento).filter_by(periodo=period_id).count()
        if count > 0:
            raise AppIntegrityError(f"No se puede eliminar el período {period_id} porque tiene {count} vencimientos asociados.")
        
        # 2. Delete
        p = session.query(PeriodoContable).filter_by(periodo_id=period_id).first()
        if p:
            session.delete(p)
            return True
        return False

    @staticmethod
    @safe_transaction
    def get_all_periods(session=None):
        return session.query(PeriodoContable).order_by(PeriodoContable.periodo_id.desc()).all()


