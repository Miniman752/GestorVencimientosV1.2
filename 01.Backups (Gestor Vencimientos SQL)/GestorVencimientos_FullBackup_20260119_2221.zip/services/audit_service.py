from datetime import datetime
from database import SessionLocal
from models.entities import AuditLog
from utils.logger import app_logger

class AuditService:
    def log(self, module: str, action: str, entity_id: str = None, old_value: str = None, new_value: str = None, details: str = None, user_id: str = "System"):
        """
        Registra una acción en el log de auditoría.
        """
        db = SessionLocal()
        try:
            log_entry = AuditLog(
                timestamp=datetime.now().isoformat(),
                module=module,
                action=action,
                entity_id=entity_id,
                old_value=str(old_value) if old_value is not None else None,
                new_value=str(new_value) if new_value is not None else None,
                details=details,
                user_id=user_id
            )
            db.add(log_entry)
            db.commit()
            return True
        except Exception as e:
            app_logger.error(f"Audit Log Failed: {e}")
            return False
        finally:
            db.close()

    def get_logs(self, module=None, entity_id=None, limit=50):
        db = SessionLocal()
        try:
            query = db.query(AuditLog)
            if module:
                query = query.filter(AuditLog.module == module)
            if entity_id:
                query = query.filter(AuditLog.entity_id == entity_id)
            
            return query.order_by(AuditLog.id.desc()).limit(limit).all()
        except Exception as e:
            app_logger.error(f"Audit Fetch Failed: {e}")
            return []
        finally:
            db.close()


