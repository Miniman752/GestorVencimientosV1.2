import customtkinter as ctk
from datetime import date, timedelta
from config import COLORS, FONTS

class TimeNavigatorView(ctk.CTkFrame):
    def __init__(self, master, on_change_command=None, **kwargs):
        super().__init__(master, **kwargs)
        self.configure(fg_color="transparent")
        
        self.on_change = on_change_command
        self.current_date = date.today().replace(day=1) # Always 1st of month

        # Layout
        self.btn_prev = ctk.CTkButton(self, text="<<", width=40, command=self.go_prev, fg_color=COLORS["secondary_button"])
        self.btn_prev.pack(side="left", padx=5)

        self.lbl_period = ctk.CTkLabel(self, text=self.format_label(), font=("Segoe UI", 16, "bold"), width=150, text_color=COLORS["text_primary"])
        self.lbl_period.pack(side="left", padx=5)

        self.btn_next = ctk.CTkButton(self, text=">>", width=40, command=self.go_next, fg_color=COLORS["secondary_button"])
        self.btn_next.pack(side="left", padx=5)
        
        # Status Icon (Lock/Open)
        self.lbl_status = ctk.CTkLabel(self, text="🔓", font=("Segoe UI", 16))
        self.lbl_status.pack(side="left", padx=10)

    def format_label(self):
        months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
        m = months[self.current_date.month - 1]
        return f"{m} {self.current_date.year}"

    def go_prev(self):
        # Subtract one month
        # Logic: First day of previous month
        self.current_date = (self.current_date.replace(day=1) - timedelta(days=1)).replace(day=1)
        self.update_ui()
        if self.on_change: self.on_change(self.current_date)

    def go_next(self):
        # Add one month logic
        # Logic: First day of next month
        # Quick hack: Add 32 days then reset to 1
        self.current_date = (self.current_date.replace(day=1) + timedelta(days=32)).replace(day=1)
        self.update_ui()
        if self.on_change: self.on_change(self.current_date)

    def update_ui(self):
        self.lbl_period.configure(text=self.format_label())

    def set_lock_status(self, is_locked: bool):
        icon = "🔒" if is_locked else "🔓"
        color = COLORS["status_overdue"] if is_locked else COLORS["status_paid"]
        self.lbl_status.configure(text=icon, text_color=color)


