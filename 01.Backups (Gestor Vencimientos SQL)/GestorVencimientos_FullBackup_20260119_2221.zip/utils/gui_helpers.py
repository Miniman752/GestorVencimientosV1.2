
def center_window(window, parent):
    """
    Centers a Toplevel window relative to its parent.
    """
    window.update_idletasks()
    try:
        width = window.winfo_width()
        height = window.winfo_height()
        # Calculate position relative to parent
        x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (width // 2)
        y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (height // 2)
        window.geometry(f'+{x}+{y}')
    except Exception:
        pass
