import sys
import os
from datetime import date

# Add src_restored to path
sys.path.append(os.path.abspath("e:/43.Gestor de vencimientos/07.Gestor de vencimientos/src_restored"))

from services.dashboard_service import DashboardService
from database import SessionLocal
from models.entities import Vencimiento, EstadoVencimiento, Pago

def debug_dashboard():
    session = SessionLocal()
    try:
        service = DashboardService()
        today = date.today()
        current_period = today.strftime("%m-%Y")
        
        print(f"--- Debug Dashboard Savings for {current_period} ---")
        
        # 1. Call Service Method
        stats = service.get_savings_stats(current_period, session=session)
        print("Service Result:", stats)
        
        # 2. Manual Query Inspection - DUMP ALL
        print("\n--- DUMP ALL VENCIMIENTOS ---")
        rows = session.query(Vencimiento).all()
        
        print(f"Found {len(rows)} Total Vencimientos:")
        for v in rows:
            print(f"ID: {v.id} | Period: {v.periodo} | Date: {v.fecha_vencimiento} | Status: {v.estado} | M.Orig: {v.monto_original}")
            if v.pagos:
                 for p in v.pagos:
                     print(f"   -> PAGO: Date: {p.fecha_pago} | Monto: {p.monto}")
            else:
                 print("   -> NO PAYMENTS")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    debug_dashboard()
