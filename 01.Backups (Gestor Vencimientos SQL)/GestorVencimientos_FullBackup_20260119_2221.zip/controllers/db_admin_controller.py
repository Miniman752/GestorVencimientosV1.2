import os
import shutil
import sqlite3
import pandas as pd
from datetime import datetime
from config import DB_NAME, DATABASE_URL, get_backup_dir, set_backup_dir, get_admin_password
from database import SessionLocal
from models.entities import Obligacion, ReglaAjuste, TipoAjuste, CategoriaServicio

from utils.logger import app_logger
import subprocess
import platform

class DbAdminController:
    def __init__(self):
        # Determine actual DB path from DATABASE_URL
        self.db_url = DATABASE_URL
        self.is_cloud = "postgres" in self.db_url or "neon.tech" in self.db_url
        
        if self.is_cloud:
            self.db_path = self.db_url # Not a file path
        else:
             self.db_path = DATABASE_URL.replace("sqlite:///", "") 
             
        self.backup_dir = get_backup_dir()
        
        if not self.backup_dir.exists():
            self.backup_dir.mkdir(parents=True, exist_ok=True)

    def set_custom_backup_path(self, path):
        """Updates the backup path in config and controller."""
        set_backup_dir(path)
        self.backup_dir = split_path = get_backup_dir() # Reload to be sure
        if not self.backup_dir.exists():
            self.backup_dir.mkdir(parents=True, exist_ok=True)
        return True, "Ruta actualizada correctamente."

    def create_quick_backup(self):
        """
        Creates a lightweight JSON backup of critical data.
        Much faster than Excel export for exit routine.
        """
        import json
        import gzip
        from datetime import datetime
        from models.entities import Vencimiento, Pago, Obligacion, Inmueble, ProveedorServicio
        from database import SessionLocal
        from datetime import date
        
        session = SessionLocal()
        try:
            data = {}
            
            # Helper: Row to Dict
            def to_dict(obj):
                d = {}
                for c in obj.__table__.columns:
                     val = getattr(obj, c.name)
                     if isinstance(val, (date, datetime)):
                         val = val.isoformat()
                     elif hasattr(val, "value"): # Handle Enums
                         val = val.value
                     d[c.name] = val
                return d

            # 1. Vencimientos
            vencs = session.query(Vencimiento).all()
            data["vencimientos"] = [to_dict(x) for x in vencs]
            
            # 2. Pagos
            pagos = session.query(Pago).all()
            data["pagos"] = [to_dict(x) for x in pagos]
            
            # 3. Obligaciones (Critical Config)
            obs = session.query(Obligacion).all()
            data["obligaciones"] = [to_dict(x) for x in obs]
            
            # 4. Inmuebles
            inms = session.query(Inmueble).all()
            data["inmuebles"] = [to_dict(x) for x in inms]

            # 5. Proveedores
            provs = session.query(ProveedorServicio).all()
            data["proveedores"] = [to_dict(x) for x in provs]
            
            timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")
            filename = f"SIGV_QuickBackup_{timestamp}.json.gz"
            final_path = self.backup_dir / filename
            
            # Ensure dir
            if not self.backup_dir.exists():
                self.backup_dir.mkdir(parents=True, exist_ok=True)
            
            with gzip.open(final_path, 'wt', encoding='utf-8') as f:
                json.dump(data, f)
                
            return str(final_path)
            
        except Exception as e:
            app_logger.error(f"Error creating quick backup: {e}")
            return None
        finally:
            session.close()

    def open_backup_folder(self):
        """Opens the backup directory in the OS file explorer."""
        path = str(self.backup_dir)
        try:
            if platform.system() == "Windows":
                os.startfile(path)
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
            return True, "Carpeta abierta."
        except Exception as e:
            app_logger.error(f"Error opening folder: {e}")
            return False, f"No se pudo abrir la carpeta: {e}"

    def create_backup(self, custom_dest=None):
        """Creates a timestamped copy of the database. 
        If custom_dest is provided (Path object), copies there instead of default backup path."""
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")
            backup_filename = f"SIGV_Backup_{timestamp}.db"
            
            target_dir = custom_dest if custom_dest else self.backup_dir
             
            # Ensure target exists
            if not target_dir.exists():
                target_dir.mkdir(parents=True, exist_ok=True)

            if self.is_cloud:
                # Cloud Backup -> Export to Excel/Dump
                backup_filename = f"SIGV_CloudBackup_{timestamp}.xlsx"
                backup_path = target_dir / backup_filename
                success, msg = self.export_to_excel_full(str(backup_path))
                if not success: raise Exception(msg)
            else:
                # Local Backup -> File Copy
                backup_filename = f"SIGV_Backup_{timestamp}.db"
                backup_path = target_dir / backup_filename
                shutil.copy2(self.db_path, backup_path)
                
            app_logger.info(f"Backup created: {backup_path}")
            return True, f"Backup created successfully: {os.path.basename(backup_path)}"
        except Exception as e:
            app_logger.error(f"Backup failed: {e}")
            return False, str(e)

    def restore_database(self, backup_path, password):
        """Restores the database from a backup file."""
        if password != get_admin_password():
            return False, "Invalid password."

        if not os.path.exists(backup_path):
            return False, "Backup file not found."

        try:
            # Close existing connections? 
            # In SQLite with file copy, it's risky if the app has the file open.
            # Ideally we should close the session/engine, but for this desktop app
            # a simple copy overwrite might work if no transaction is active.
            # A safer way is ensuring no write is happening.
            
            shutil.copy2(backup_path, self.db_path)
            app_logger.info(f"Database restored from: {backup_path}")
            return True, "System restored successfully. Please restart the application."
        except Exception as e:
            app_logger.error(f"Restore failed: {e}")
            return False, str(e)
            
    def export_to_excel_full(self, target_path):
        """Exports all tables to a multi-sheet Excel file (Handles both SQLite and Postgres)."""
        try:
            from sqlalchemy import create_engine, inspect
            
            # Use SQLAlchemy for agnostic connection
            engine = create_engine(self.db_url)
            inspector = inspect(engine)
            
            # Get table names compatible with both
            tables = inspector.get_table_names()
            
            with pd.ExcelWriter(target_path, engine='openpyxl') as writer:
                with engine.connect() as conn:
                    for table in tables:
                        df = pd.read_sql_table(table, conn)
                        df.to_excel(writer, sheet_name=table[:31], index=False) # Excel sheet name limit 31 chars
            
            return True, "Export successful."
        except Exception as e:
            app_logger.error(f"Excel export failed: {e}")
            return False, str(e)
            
    def export_to_sql_dump(self, target_path):
        """Exports the database to a SQL dump file."""
        try:
            conn = sqlite3.connect(self.db_path)
            with open(target_path, 'w', encoding='utf-8') as f:
                for line in conn.iterdump():
                    f.write('%s\n' % line)
            conn.close()
            return True, "SQL Dump successful."
        except Exception as e:
            app_logger.error(f"SQL export failed: {e}")
            return False, str(e)
    
    def get_backups_list(self):
        """Returns a list of available backup files."""
        if not self.backup_dir.exists():
            return []
        
        files = [f for f in self.backup_dir.glob("*.db") if f.name.startswith("SIGV_Backup_")]
        return sorted(files, key=lambda f: f.stat().st_mtime, reverse=True)
        
    def apply_default_rules(self):
        """
        Applies default Adjustment Rules to Obligations that have none.
        - Taxes/Services/Expenses -> ESTACIONAL_IPC
        - Others -> FIJO
        Returns: count of updated records
        """
        db = SessionLocal()
        count = 0
        try:
            # 1. Find Obs without rules
            obs_no_rule = db.query(Obligacion).outerjoin(ReglaAjuste).filter(ReglaAjuste.id == None).all()
            
            for o in obs_no_rule:
                # Determine rule based on category
                cat = o.proveedor.categoria if o.proveedor else None
                new_rule = TipoAjuste.FIJO # Default
                
                if cat in [CategoriaServicio.IMPUESTO, CategoriaServicio.EXPENSA, CategoriaServicio.SERVICIO]:
                    new_rule = TipoAjuste.ESTACIONAL_IPC
                
                # Create Regla
                regla = ReglaAjuste(
                    obligacion_id=o.id,
                    tipo_ajuste=new_rule,
                    frecuencia_meses=1
                )
                db.add(regla)
                count += 1
            
            db.commit()
            return True, f"Se actualizaron {count} obligaciones con reglas por defecto."
            
        except Exception as e:
            db.rollback()
            app_logger.error(f"Error applying default rules: {e}")
            return False, str(e)
        finally:
            db.close()

    def migrate_sqlite_to_postgres(self, target_url):
        """
        Migrates data from current SQLite DB to the target PostgreSQL DB.
        """
        try:
            from sqlalchemy import create_engine, text
            from models.entities import Base
            from database import engine as current_engine # Use active engine
            # Import all models to ensure registry is populated
            from models.entities import Inmueble, ProveedorServicio, Obligacion, Vencimiento, Pago, Usuario, Credencial, IndiceEconomico, Cotizacion, PeriodoContable, AuditLog, ReglaAjuste
            
            app_logger.info(f"Starting migration to: {target_url}")
            
            # 1. Source Connection (Current)
            # Use the existing engine to avoid path/locking issues
            source_engine = current_engine
            
            # 2. Target Connection
            target_engine = create_engine(target_url)
            
            # 3. Create Schema
            Base.metadata.create_all(target_engine)
            
            # 4. Migrate Data (Ordered by dependency)
            tables = [
                "usuarios", 
                "inmuebles", 
                "proveedores", 
                "obligaciones", 
                "reglas_ajuste", 
                "vencimientos", 
                "pagos", 
                "indices_economicos", 
                "cotizaciones", 
                "periodos_contables", 
                "credenciales",
                "audit_logs"
            ]
            
            
            with source_engine.connect() as src_conn:
                with target_engine.connect() as tgt_conn:
                    trans = tgt_conn.begin()
                    try:
                        # CLEAN TARGET FIRST (To avoid duplicates from partial runs)
                        # We use TRUNCATE CASCADE to clear everything safely
                        tgt_tables_sql = ", ".join([f'"{t}"' for t in tables])
                        try:
                            tgt_conn.execute(text(f"TRUNCATE TABLE {tgt_tables_sql} RESTART IDENTITY CASCADE"))
                        except Exception:
                            # Might fail if tables don't exist yet (first run), which is fine
                            pass

                        for table in tables:
                            # Read
                            df = pd.read_sql_table(table, src_conn)
                            if not df.empty:
                                # Write
                                df.to_sql(table, tgt_conn, if_exists='append', index=False)
                                
                                # Reset Sequence (Postgres)
                                if 'id' in df.columns:
                                    try:
                                        seq_sql = text(f"SELECT setval(pg_get_serial_sequence('{table}', 'id'), coalesce(max(id), 1)) FROM {table}")
                                        tgt_conn.execute(seq_sql)
                                    except Exception as ex:
                                        app_logger.warning(f"Could not reset sequence for {table}: {ex}")
                                    
                        trans.commit()
                        return True, "Migration completed successfully."
                    except Exception as e:
                        trans.rollback()
                        raise e
                        
        except Exception as e:
            app_logger.error(f"Migration failed: {e}")
            return False, f"Migration Error: {e}"


