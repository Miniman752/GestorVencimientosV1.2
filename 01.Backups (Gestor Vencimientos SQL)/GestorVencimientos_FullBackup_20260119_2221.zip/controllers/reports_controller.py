from services.report_service import ReportService
from utils.logger import app_logger

class ReportsController:
    def __init__(self):
        self.service = ReportService()

    def export_excel(self, vencimientos, filename="export_vencimientos.xlsx"):
        try:
            return self.service.export_excel(vencimientos, filename)
        except Exception as e:
            app_logger.error(f"Error Export Excel: {e}")
            raise e

    def export_pdf_report(self, vencimientos, filename="reporte_deuda.pdf"):
        try:
            return self.service.export_pdf(vencimientos, filename)
        except Exception as e:
            app_logger.error(f"Error Export PDF: {e}")
            raise e


